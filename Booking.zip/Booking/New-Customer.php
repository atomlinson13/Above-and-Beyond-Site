<!DOCTYPE html>

<html>
<head>
<title>Sign In - TruQA</title>
      <meta charset="UTF-8">
	  <meta name="description" content="Above and Beyond is a B&B located in the mountains of OK Falls near Penticton.">
	  <meta name="keywords" content="B&B, Bed and Breakfast, travel, hotel, inn, room, rent, rentals, penticton, Ok Falls, Mountains, View, Pool">
	  <meta name="author" content="Amanda Tomlinson">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	   
     <title>Above and Beyond B&amp;B</title>
   

      <script src="modernizr-1.5.js" type="text/javascript" ></script>
      <link href="theme.css" rel="stylesheet" type="text/css" />
	  <link href="contact.css" rel="stylesheet" type="text/css" /> 
	  <script src="contact.js" type="text/javascript"></script>		
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	  
	
<style>

	* {
		
		color: white;
		
	}
        #blanket {
            display: none;
			width: 100%;
            height: 100%;
            position: fixed;
            top:0;
            left:0;
            opacity: 0.2;  
            background-color: Grey;
            z-index: 998; 
        }

        .modal-window {
            display: none;
			clear: left;
            width: 70%;
            height: 500px;
            position: absoloute; 
            top: 150px;
            <!--left: calc(50% - 250px); -->
			border: double;
			border-color: white;
			border-color: rgba(145,200,213,0.84);
			padding-right: 0px;
            padding: 20px;
            z-index: 999; 
        }
        .modal-label {
            display:inline-block;
            width:100px;
        }	
		
		h2 {
			font-family: bad-script;
			font-size: 23px;
			font-style: normal;
			font-weight: 400;	
		}

		#container {
			margin-top: -20px;
			font-family: bad-script;
			font-size: 18px;
			font-style: normal;	
		}
		
		p {
			width: 100%;
		}
		
		#pick {
			display: none;
			border: double;
			position: absoloute; 
			clear: left;
			border-color: white;
			border-color: rgba(145,200,213,0.84);
			height: 185px;

		}
		
		#new-guest {
			display: none;
			color: white;
			width: 650px;
			height: 600px;
			margin-top: -20px;
			
		}
		
		button {
			width: 100px;
			font-size: 15px;
			

		}

		
		#new-login {
			display: none;
			color: white;
			width: 600px;
			height: 280px;
			border: double;
			border-color: white;
			border-color: rgba(145,200,213,0.84);
			text-align: center;
			margin-left: 40px;
		}
		
		#confirm-book {
			display: none;
			color: white;
			width: 400px;
			height: 400px;
			float: left;
			border: double;
			clear: left;
			border-color: white;
			border-color: rgba(145,200,213,0.84);
			text-align: center;
			
		}
		
		section {
			margin-left: -70px;
			margin-bottom: 100px;
		}

		
	
</style>	

		
</head>


<header>
           
			<img src="logo6.jpg" alt="Above and Beyond" width="1500" height="400" id="banner"  usemap="#housemap" style=" margin-left:-20px;"/>
			<map name="housemap" id="housemap">
				<area alt="" title="Home Page" href="home.htm" shape="rect" coords="11,8,555,460" />
				<area alt="" title="Tour Page" href="tour.htm" shape="rect" coords="581,18,1661,474" />
			</map>

</header>
<body>



			 
			<section>
				<div id="nav" style=" clear: left; float: left; margin-left: -60px;">
				<nav class="nav">
					<ul style="">
					   <li><a href="home.htm">Home  </a></li>
					   <li><a href="tour.htm">Tour  </a></li>
					   <li><a href="activities.htm">Activities  </a></li>
					   <li><a href="rates.htm">Rates  </a></li>
					   <li><a href="contact.htm">Contact</a></li>
					   <li><a href="New-Customer.php">Bookings</a></li>
				</nav>
				</div>
			</section>
					
	

<div id="form" style="margin-top: -50px;">
    <fieldset id="bookInfo" style="width: 50%; height: 590px; position: relative; margin:0px auto; display: block;">
	 <legend>Reservation Information</legend>	 
	<div id='booking-new' style= "width: 98%; margin-top: -10px;">
			<br>
			<br>
				
				<label for="dateFrom">Date from: </label>
			    <input name="dateFrom" id="dateFrom" type="date" style="background-color: black;" />
				
				<label for="dateTo">Date to: </label>
			    <input name="dateTo" id="dateTo" type="date" style="background-color: black;" />
							
				<label for="room">Choose a room: </label>
				<select name="room" id="room" required>
				    <option value="default">-----</option>
					<option value="Cedar">Cedar Master</option>
					<option value="Birch">Birch Master</option>
					<option value="Dogwood">Dogwood Junior</option>
					<option value="Un-decided">Undecided</option>
				</select>
				<h3 id="display1" style=" clear: left; display: block;   height: 20px;  width: 200px;   color: red;"> <?php if (!empty($error_msg)) echo $error_msg; ?> </h3>
	
				<label for="guestNum">Number of Guests: (Max 4)</label>
				<select name="guestNum" id="guestNum" required>
					<option value="0">0</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
				</select>
			    
				<label for="message">Additonal Requests</label>		
			    <textarea name ="requests" id="requests" style="width: 100%;"></textarea>
				<br>
				<br>
				
				
				<button id="submit-button" type="button" style="position: absolute; left: 10; bottom:1; margin-bottom: 3px;">Submit</button>
	</div>	
	
	</fieldset>
</div>


       
		
		<div id="new-guest" style="margin-left: 20px;">
		<fieldset id="custInfo" style=" width: 60%; height: 500px; position: relative; margin: 0px auto; display: block;">
		<legend style="color: aliceblue;">Customer Information</legend>	 
		<div id='booking-new' style= "width: 100%;">
				<input type='hidden' name='page' value='customerBooking'></input>
				<input type='hidden' name='command' value='new-info'></input>
				
				<label class='modal-label'style="display: inline;">First Name:</label> 
				<input type='text' name='firstName' id='firstName' placeholder='Enter first name' required></input>
				
				<label class='modal-label'>Last Name:</label> 
				<input type='text' name='lastName' id='lastName' placeholder='Enter last name' required></input>
				
				<label class='modal-label'>City:</label> 
				<input type='text' name='city' id='city'placeholder='Enter city' required></input>
				
				<label class='modal-label'>Address:</label> 
				<input type='text' name='address' id='address' placeholder='Enter address' required></input>
				
				<label class='modal-label'>Phone:</label> 
				<input name="phone" id="phone" type="tel" id='phone' placeholder="(nnn) nnn-nnnn" />
				
				<label class='modal-label'>Email:</label> 
				<input type='text' name='email' id="email" placeholder='Enter email address' required></input>
			
				<label class='modal-label'>Password:</label> 
				<input type='password' name='password' id="password" placeholder='Enter password' required></input>
				<br>
				<br>
				<button id="submit-cust" type="button" style="position: absolute; left: 10; bottom:10; margin-bottom: 3px;">Submit</button>	
		</div>			
		</fieldset>
		</div>
	
	
		
		<div id="confirm-book" style="float: left; width: 40%;">
		<h2 style='text-align: center; letter-spacing: 1px; font-family: bad-script; color:  white;'>Confirm Booking</h2>
		</div>
		
		
		
			
		
		<div id="new-login">
		    <fieldset style="border: none; position: relative; margin: 0px auto; display: block; height: 250px;">
			<form method='post' action='controller.php'>
			<h2 style="text-align: center; letter-spacing: 1px; font-family: bad-script; color:  white;">Login</h2>
			<br>	
			 <input type='hidden' name='page' value='Login'></input>
            <input type='hidden' name='command' value='find'></input>
			<label class='modal-label'>Email:</label> 
			<input type='text' name='email' id='email2' placeholder='Enter email address' required></input>
			<br>
			<label class='modal-label'>Password:</label> 
			<input type='password' name='password' id='password2' placeholder='Enter password' required></input>
			<button id="login-btn2" type="button" style="position: absolute; left: 10; bottom:10; margin-bottom: 3px;" onlick="Login()">Login</button>
			</form>
			</fieldset>
			
		</div>
		
	
			

		
		
		
<div id="pick" style="width: 30%; margin: 60px auto; text-align: center;">
<h2>Above and Beyond</h2>

 <button id="login-btn" type="button" onclick="returnGuest()">Log In</button>
 <p>OR</p>
 <button id="new-btn" type="button" onclick="newGuest()">New Guest</button>
 
</div>

<div id="container" style=" width: 75%; display: block; margin: 0px auto;"> </div>

<script>
function Login() {
			
	        var url = "controller.php";
            var query = { page: 'Login', command: 'find', email:$('#email2').val(), password:$('#password2').val() };
            $.post(url,
						query,
						function() {
							
						}
			);
}




</script>
	
<script>
$('#submit-cust').click(function() {
	        var url = "controller.php";
			var query = { page: 'customerBooking', command: 'check2', firstName:$('#firstName').val(), lastName:$('#lastName').val(), city:$('#city').val(), address:$('#address').val(), phone:$('#phone').val(), email:$('#email').val(), password:$('#password').val() };
						
			 $.post(url,
                    query,
                    function() {
                        alert("Information Submitted!");  
                    }
            );
}); 

</script>
<script>
$('#room').blur(function() {
	
	       
						
			var url = "controller.php";
            var query = { page: 'Booking', command: 'check', dateFrom:$('#dateFrom').val(), dateTo:$('#dateTo').val(), room:$('#room').val() };
            $.post(url,
                    query,
                    function(data) {
                        $('#display1').html('It is: ' + data);  
                    }
            );

			
		
				
});

</script>	


<script>
      
	function newGuest() {
			document.getElementById("confirm-book").style.display = "block";
			document.getElementById("new-guest").style.display = "inline-block";	
			document.getElementById("form").style.display = "none";
			document.getElementById("pick").style.display = "none";
			
			 $('#container').append( $('#confirm-book') );
			 $('#container').append( $('#new-guest') );
		  
	}
		

</script>		

<script>
      
	function returnGuest() {
		  
			document.getElementById("new-guest").style.display = "none";	
			document.getElementById("confirm-book").style.display = "block";		
			document.getElementById("form").style.display = "none";
			document.getElementById("new-login").style.display = "inline-block";
		    document.getElementById("pick").style.display = "none";
			
			
			 $('#container').append( $('#confirm-book') );
			 $('#container').append( $('#new-login') );
		  
	}
		

</script>	
	
<script>
		
        $("button#submit-button").click(function(e) {	
		  
			
			
			var fname = $( "#firstName" ).val();
			var lname = $( "#lastName" ).val();
			var city = $( "#city" ).val();
			var address = $( "#address" ).val();
			var phone = $( "#phone" ).val();
			
			
			$("#confirm-info").append("<p>First Name: " + fname + "</p>");
			$("#confirm-info").append("<p>Last Name: " + lname + "</p>");
			$("#confirm-info").append("<p>City: " + city + "</p>");
			$("#confirm-info").append("<p>Address: " + address + "</p>");
			$("#confirm-info").append("<p>Phone: " + phone + "</p>");
			
			
			var dateTo = $( "#dateTo" ).val();
			var dateFrom = $( "#dateFrom" ).val();
			var room = $( "#room" ).val();
			var guestNum = $( "#guestNum" ).val();
			var requests = $( "#requests" ).val();
			var cedar = 250;
			var birch = 150;
			var dogwood = 100;
			
			
				
			$("#confirm-book").append("<p>Date From: " + dateFrom + "</p>");
			$("#confirm-book").append("<p>Date To: " + dateTo + "</p>");
			$("#confirm-book").append("<p>Room: " + room + "</p>");
			$("#confirm-book").append("<p>Number of Guests: " + guestNum + "</p>");
			
			
			
			
			var date1 = new Date($('#dateTo').val());

			var date2 = new Date($('#dateFrom').val());
		
			var timeDiff = Math.abs(date2.getTime() - date1.getTime());
			var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 
			$("#confirm-book").append("<p>Nights : " + diffDays + "</p>");		
			var price; 
			
			if(room == 'Cedar')  {
					price = cedar*diffDays;
			} else if(room == 'Birch')  { 
					price = birch*diffDays;	
			} else if(room == 'Dogwood')  { 
					price = dogwood*diffDays;	
			}	else {
				price = "To be determined";
			}

			function numberWithCommas(x) {
				return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
			}
			
			if(guestNum>2) {
				var extra = guestNum-2;
				price = price + (extra*40);
			} 
			
			
			price = numberWithCommas(price);
			$("#confirm-book").append("<p>Price: $" + price + "</p>");
			$("#confirm-book").append("<p>Requests: " + requests + "</p>");
			
			
			
			
			document.getElementById("pick").style.display = "block";
			document.getElementById("form").style.display = "none";
			
			
			
				var url = "controller.php";
				var query = { page: 'Booking', command: 'checking', dateFrom:$('#dateFrom').val(), dateTo:$('#dateTo').val(), room:$('#room').val(), guestNum:$('#guestNum').val(), requests:$('#requests').val() };
				$.post(url,
						query,
						function() {
							alert('sent!');
						}
				);	
				
				
			

			
					
			
			
		});	
		
		
	
</script>


			


</body>
</html>	
	  