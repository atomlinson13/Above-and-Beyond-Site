<?php
$conn = mysqli_connect('localhost', 'atom', 'atom', 'COMP3540_atom');

function insert_new_user($firstName, $lastName, $city, $address, $phone, $email)
{
    global $conn;
    
    if (does_exist($email))
        return false;
    else {
        $current_date = date('Ymd');
        $sql = "insert into Guest values (NULL, '$firstName', '$lastName', '$address', '$city', '$phone', '$email', $password)";
        $result = mysqli_query($conn, $sql);
        return $result;
    }
}

function is_valid($email, $password) 
{
    global $conn;
    
    $sql = "select * from Guest where (email = '$email' and password = '$password')";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0)
        return true;
    else
        return false;
}

function does_exist($email) 
{
    global $conn;
    
    $sql = "select * from Guest where (email = '$email')";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0)
        return true;
    else
        return false;
}


function get_userid($email)
{
    global $conn;
    
    $sql = "select * from Guest where (email = '$email')";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        return $row['custID'];
    }
    else
        return -1;
}


function get_roomid($roomName)
{
    global $conn;
    
    $sql = "select * from Room where (roomName = '$roomName')";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        return $row['roomID'];
    }
    else
        return -1;
}

/*
*   Queries
*/
function save_guest($fName, $lName, $address, $city, $phone, $email, $password)  // question, username
{
    global $conn;
    
    
   
	
    $sql = "insert into Guest values (NULL, '$fName', '$lName', '$address', '$city', '$phone', '$email', '$password')";
    $result = mysqli_query($conn, $sql);
    return $result;
    

}


function save_booking($dateFrom, $dateTo, $requests, $numGuest, $email, $room)  
{
    global $conn;
    
    $uid = get_userid($email);  // use get_userid()
    if ($uid < 0)
       $uid = 1;
    
	$rid = get_roomid($room);  // use get_userid()
    if ($rid < 0)
       $rid = 1;

	
    $sql = "insert into Booking values (NULL, $uid, $rid, '$dateFrom', '$dateTo', '$requests', $numGuest)";
    $result = mysqli_query($conn, $sql);
    return $result;
    

}


function is_available($dateFrom, $dateTo, $room)
{
	
	global $conn;
	
	
	
	$rid = get_roomid($room);
	
	$sql = "select * from Booking where (roomID = $rid and ('$dateTo' between dateFrom and dateTo or '$dateFrom' between dateFrom and dateTo))";
    $result = mysqli_query($conn, $sql);
	if (mysqli_num_rows($result) > 0) 
	{
        return false;
    } else {
        return true;
	}
}

function list_data($u)
{
    global $conn;
    
    $uid = get_userid($u);
    if ($uid < 0)
        return '';
    
    $sql = "select * from Booking where (CustID = $uid)";
    $result = mysqli_query($conn, $sql);
    $data = array();
    $i = 0;
    while($row = mysqli_fetch_assoc($result))
        $data[$i++] = $row;
    
    return $data;

	
	}
?>   



?>