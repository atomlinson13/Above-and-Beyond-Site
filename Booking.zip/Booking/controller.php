<?php

if (empty($_POST['page'])) {  // When no page is sent from the client; The initial display
                                // You may use if (!isset($_POST['page'])) instead of empty(...).
    echo 'Hello';						  
    include ('New-Customer.php');
	exit();
	    
} 


require('modal.php');  // This file includes some routines to use DB.


if ($_POST['page']=='Booking')
{
	
	$command = $_POST['command'];
	
	if($_POST['room'] == 'default' || $_POST['room'] == 'Un-decided')
	{
		$error_msg = '';
		echo $error_msg;
		
	} 
	else if(is_available($_POST['dateFrom'], $_POST['dateTo'], $_POST['room'])) 
	{	
				    $error_msg = 'Available';
					echo $error_msg;
					//include ('New-Customer.php');
					
	} else {
					$error_msg = 'Un-Available';
					echo $error_msg;
					//include ('New-Customer.php');
					
	}	        
	
	
	
	if($command == 'checking') 
	{
		        session_start();
				$_SESSION['signedin'] = 'YES';
                $_SESSION['dateTo'] = $_POST['dateTo'];
				$_SESSION['dateFrom'] = $_POST['dateFrom'];
				$_SESSION['room'] = $_POST['room'];
                $_SESSION['guestNum'] = $_POST['guestNum'];
				$_SESSION['requests'] = $_POST['requests']; 
	}
	
	if($command == 'signout') 
	{	
	 session_unset();
     session_destroy();
     include('New-Customer.php');
	}
				
				
	   		
	exit();		
			
			
		
} 
else if ($_POST['page'] == 'customerBooking') 
{	
		session_start();
		
		// check if this session is broken using $_SESSION['signedin']
		if (!isset($_SESSION['signedin']) || $_SESSION['signedin'] != 'YES') {
			echo 'Session is broken<br>';
			exit();
		}
			
	     $dateTo = $_SESSION['dateTo'];
		 $dateFrom = $_SESSION['dateFrom'];
		 
		 $room = $_SESSION['room'];
		 $guestNum = $_SESSION['guestNum'];
		 $requests = $_SESSION['requests'];	
	
		 $fName = $_POST['firstName'];
		 $lName = $_POST['lastName'];
		 $city = $_POST['city'];
		 $address = $_POST['address'];
		 $phone = $_POST['phone'];
		 
		 $email = $_POST['email'];
		 $password = $_POST['password'];
		 
		 
		 
		
		
		save_guest($fName, $lName, $address, $city, $phone, $email, $password);		
		
		save_booking($dateFrom, $dateTo, $requests, $guestNum, $email, $room);	
		
		
		
		

	
		include ('New-Customer.php');
		exit();
	
} 


if ($_POST['page'] == 'Login') 
{
	
	

	    session_start();
		
		
		if (!isset($_SESSION['signedin']) || $_SESSION['signedin'] != 'YES') {
			echo 'Session is broken<br>';
			exit();
		}
		
	    $dateTo = $_SESSION['dateTo'];
		$dateFrom = $_SESSION['dateFrom'];
		 
		$room = $_SESSION['room'];
		$guestNum = $_SESSION['guestNum'];
		$requests = $_SESSION['requests'];	
		 
		$email = $_POST['email2'];
		$password = $_POST['password2'];
	
		if(does_exist($email) && is_valid($email, $password))
		{
			
			save_booking($dateFrom, $dateTo, $requests, $guestNum, $email, $room);	
			include('Login.php');
			
		} else {
			
			include ('New-Customer.php');
			
			
		}
		exit();
		
		
		
		/*
		$r = list_questions($username);  // in model.php
                                             // the return value is an array of associative arrays
            $str = json_encode($r);  // convert a linear of associative arrays into a JSON string and echo it.
            echo $str;
		
			*/
}	else {
	
	echo 'youre screwed';
	
}			

?>   
