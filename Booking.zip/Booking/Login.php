
<!DOCTYPE html>

<html>
<head>
<title>Above and Beyond B&amp;B</title>
      <meta charset="UTF-8">
	  <meta name="description" content="Above and Beyond is a B&B located in the mountains of OK Falls near Penticton.">
	  <meta name="keywords" content="B&B, Bed and Breakfast, travel, hotel, inn, room, rent, rentals, penticton, Ok Falls, Mountains, View, Pool">
	  <meta name="author" content="Amanda Tomlinson">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	   
     <title>Above and Beyond B&amp;B</title>
   

   
      <link href="theme.css" rel="stylesheet" type="text/css" />
	  <link href="contact.css" rel="stylesheet" type="text/css" /> 
	  <script src="contact.js" type="text/javascript"></script>		
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

    
    
   
</head>



<header>
           
			<img src="logo6.jpg" alt="Above and Beyond" width="1500" height="400" id="banner"  usemap="#housemap" style=" margin-left:-20px;"/>
			<map name="housemap" id="housemap">
				<area alt="" title="Home Page" href="home.htm" shape="rect" coords="11,8,555,460" />
				<area alt="" title="Tour Page" href="tour.htm" shape="rect" coords="581,18,1661,474" />
			</map>

</header>
<body>



			 
			<section>
				<div id="nav" style=" clear: left; float: left; margin-left: -60px;">
				<nav class="nav">
					<ul style="">
					   <li><a href="home.htm">Home  </a></li>
					   <li><a href="tour.htm">Tour  </a></li>
					   <li><a href="activities.htm">Activities  </a></li>
					   <li><a href="rates.htm">Rates  </a></li>
					   <li><a href="contact.htm">Contact</a></li>
					   <li><a href="New-Customer.php">Bookings</a></li>
				</nav>
				</div>
			</section>

	        
    
</body>
</html>